<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout xmlns:android="http://schemas.android.com/apk/res/android"
        xmlns:app="http://schemas.android.com/apk/res-auto"
        xmlns:tools="http://schemas.android.com/tools"
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        tools:context=".SplashScreenActivity"
        android:background="@color/white">

<ImageView
        android:id="@+id/logoImageView"
                android:layout_width="match_parent"
                android:layout_height="match_parent"
                android:src="@drawable/localestablishmentguide">

</ImageView>

<TextView
        android:id="@+id/helloMessageTextView"
                android:visibility="gone"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:textStyle="italic"
                android:textSize="30sp"
                android:text="@string/helloMessage"
                app:layout_constraintBottom_toBottomOf="parent"
                app:layout_constraintStart_toStartOf="parent"
                app:layout_constraintEnd_toEndOf="parent"
                app:layout_constraintTop_toTopOf="parent" />


</androidx.constraintlayout.widget.ConstraintLayout>}